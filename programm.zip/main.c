#include "lr.h"

int main(){
  printf("введите номер работы  ") ;
    int chaus ;
    scanf("%d",&chaus);
    printf("введите доп  ") ;
    int cl;
    scanf("%d",&cl);
    if (cl==1){
    switch (chaus){
    case 1:
        return lr1d() ;
        break ;
    case 2 :
        return lr2d() ;
        break;
    case 3:
        return lr3d() ;
        break ;
    case 4:
        return lr4d() ;
        break ;
    case 5:
        return lr5d() ;
        break ;
    case 6:
        return lr6d() ;
        break ;
    case 7:
        return lr7d() ;
        break ;
   
    }
        
    }
    else {
    switch (chaus){
    case 1:
        return lr1() ;
        break ;
    case 2 :
        return lr2() ;
        break;
    case 3:
        return lr3() ;
        break ;
    case 4:
        return lr4() ;
        break ;
    case 5:
        return lr5() ;
        break ;
    case 6:
        return lr6() ;
        break ;
    case 7:
        return lr7() ;
        break ; 
    default:
        printf("error") ;
    }
    return 0;
}
}
