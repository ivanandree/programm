#include <stdio.h>
int sort(int arr[] , int n) ;
int Glas(char c) ;
int swapDigits(int n) ;
int lr1(void) ;
int lr2(void) ;
int lr3(void) ;
int lr4(void) ;
int lr5(void) ;
int lr6(void) ;
int lr7(void) ;
int lr1d(void) ;
int lr2d(void) ;
int lr3d(void) ;
int lr4d(void) ;
int lr5d(void) ;
int lr6d(void) ;
int lr7d(void) ;
