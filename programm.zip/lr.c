#include "lr.h"
int strl(char st[]){
    int cnt=0 ;
    for (int i = 0; st[i] != '\0'; i++) cnt++ ;
    return cnt ;
}
int sort(int arr[] , int n){
    int i, j, temp;
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}
float rasch (float q,float w,float e){
    float s1;
    s1=(q+w)*e ; // вычисление расстояния 
    return s1 ;
}
int Glas(char c){
    if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'y' || c == 'Y' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
        return 1 ;
    else 
     return 0 ;
}
int swapDigits(int n) {
    if (n < 10) {
        return n;
    }
    int result = 0;
    int power = 1;
    // Меняем разряды числа 
    while (n > 10) {
        int digit1 = n % 10;
        n /= 10;
        int digit2 = n % 10;
        result += power * (10 * digit1 + digit2);
        power *= 100;
        n /= 10;
    }
result+=n*power ;
return result;
}
int lr1(void){ 
    printf(" Из пункта А в пункт Б, выехала машина со скорость  v1 км/ч\n") ; 
    float a,m,t,s ;
    printf("введите скорость автомобиля\n") ; 
    scanf("%f",&a) ;
    printf("введите скорость мотоцикла\n") ;
    scanf("%f",&m) ;
    printf("введите время встречи\n") ;
    scanf("%f",&t) ;
    s=(a+m)*t ;
    printf ("расстояние между городами %f",s) ;
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr2(void){
    printf("Вычислить сумму первых N элементов ряда: \n") ; 
        float s=0,l=1 ; 
    int n, scan=1 ;
    printf("введите количество n\n"); 
    scanf("%d",&n);
    for (int i=1;i<=n;i++){
        s=s+((scan)*(i/l)) ;
        scan=-scan ;
            l=l*2 ;
    }
    printf("сумма nервых n стрoк=%f\n",s) ;
        int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr3(void){
    printf(" В потоке символов сосчитать число слов, у которых первые две буквы совпадают.\n") ; 
    char prev_c; 
    int c,flag,cnt; 
    cnt = 0;
    flag = 0; 
    prev_c = ' ';
    while( (c = getchar()) != EOF )
     { 
        if( c == ' ' || c == '.' || c == '\n' ||  c == ',' ){ 
            flag=0 ; 
        }
        else{  
            flag++ ;
            if (flag<3 && prev_c == c){
                cnt+=1 ;
            }	
            if( flag<2 )
                prev_c = c;
            else {
                prev_c = EOF ;
            }
        }
    } 
    printf("\nколичество слов = %d\n", cnt );
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
        return 0;
}
int lr4(void){ 
    printf(" В символьной строке удалить все слова, начинающиеся с гласной буквы.\n") ; 
    char str[100],g;
    printf("Введите символьную строку: ");
    getchar();
    gets(str); 
    int i, j = 0;
    char word[100];
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] != ' ' ) {
            word[j++] = str[i];
        } else {
            word[j] = '\0';
            j = 0;
            if ((Glas(word[0]))==0) {
                printf("%s ", word);
            }
        }
    }
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr5(void){
    printf(" В массиве из 10 целых чисел найти и поменять местами минимальный и максимальный элементы.\n") ; 
    int x[10],max=0,min=1000000,mini=0,maxi=0;
    printf("вводите части мосива через энтр\n");
    for( int i=0; i < 10; i++ ) {
        scanf("%d", &x[i]);
        if (min>x[i]) {// ищим минимальный элемент запоминаем его позицию
            min=x[i];
            mini=i;
        }
        if (max<x[i]){ // ищем максимальный элемент запоминаем его строчку
            max=x[i];
            maxi=i ;
        }
    }
    x[maxi]=min; // меняем местами макс и мин элемент
    x[mini]=max;
    printf("полученный мосив\n");
    for( int i = 0; i < 10; i++ )
        printf("%d ", x[i]);
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr6(void){
   int K,N,min=1000,flag=0,i,j ;
    K=3;
    N=3;
    int x[K][N] ;
    for( i = 0; i < K; i++ ) {//ввод массива
        for( j = 0; j < N; j++ ){
            scanf("%d", &x[i][j]);
            if (min>x[i][j]) // ищем минимальные элемент запоминаем строчку
                min=x[i][j] ;
                flag=i ;
        }
    }
    printf("исходный массив \n") ;
    for( i = 0; i < K; i++ ){ // ввывод массива
        for( j = 0; j < N; j++ )
            printf("%d ", x[i][j]);
        printf("\n");
    }
    
    for( i = flag; i < K; i++ ) {// обнуляем все строчки под мин элементов
        for( j = 0; j < N; j++ ){
                x[i][j]=0 ;
        }
    }
    
    printf("полученный массив \n") ;
    for( i = 0; i < K; i++ ){ // ввывод массива
        for( j = 0; j < N; j++ )
            printf("%d ", x[i][j]);
        printf("\n");
    }

    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr7(void){
    printf(" В длинном целом числе N поменять местами нулевой разряд с первым разрядом,\n второй разряд с третьим разрядом и т.д.\n") ; 
    int number;
    printf("Введите целое число: ");
    scanf("%d", &number);
    int swappedNumber = swapDigits(number);
    printf("Число после замены разрядов: %d", swappedNumber);
        int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr1d(void){  
    float a,m,t,s ; // дробные числа
    printf("введите скорость автомобиля\n") ; 
    scanf("%f",&a) ; // скорость автомобиля
    printf("введите скорость мотоцикла\n") ;
    scanf("%f",&m) ; // скорость мотоцикла
    printf("введите время встречи\n") ;
    scanf("%f",&t) ;// время встречи
    printf ("расстояние между городами %f\n",rasch(a,m,t)) ;//вычисения расстояния между городами при помощи функции и вывод ее на консоль 
        int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0 ;
}
int lr2d(void){float s=0,l=1,k ; 
    int n,scan=1,g;
    printf("введите количество n\n"); 
    scanf("%d",&n);
    for (int i=0; i<n; i++) 
        l=l*2 ;
    l=l/2 ;
    for (int i=n;i!=0;i--){
        s=s+((scan)*(i/l)) ;
        printf("%f,%d,%d\n",s,i,scan) ;
        scan=-scan ;
        l=l/2 ;
    }
    printf("сумма nервых n стрoк=%f\n",s) ;
       int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0 ;


}
int lr3d(void){
    printf("no programm");
        int qwertyuio;
    scanf("%d",&qwertyuio) ;
    getchar();
}
int lr4d(void){
    printf(" В символьной строке удалить все слова, начинающиеся с гласной буквы но не удолять если там их две.\n") ; 
    char str[100],g;
    int cnt=0;
    getchar();
    printf("Введите символьную строку: ");
    getchar();
    gets(str); 
    int i, j = 0;
    char word[100];
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == ' ') cnt=0 ;
        else { if (Glas(str[i])==1) cnt++ ;}
        if (str[i] != ' ' && i!=strl(str)-1 )  word[j++] = str[i];
        else {
            if(i==strl(str)-1)  word[j++] = str[i];
            word[j++]='\0' ;
            j = 0;
            if ((Glas(word[0]))==0 || cnt>=2) {
                printf("%s ", word);
            }
        }
}

    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;
}
int lr5d(void){
    printf("введите маассив который надо отсортировать \n");
    int arr[10];
    int i;
     for (i = 0; i < 9; i++) {
        scanf("%d ", &arr[i]);
    }
    int n = sizeof(arr)/sizeof(arr[0]);
   
   printf("исходный массив \n");
    for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    sort(arr, n);
    printf("Отсортированный массив: \n");
    for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0;

}
int lr6d(void){
    int K,N,min=1000,flag=0,i,j,k,c;
    K=3;
    N=3;
    int x[K][N],y[K][N],z[K][N] ;
    printf("введите первый массив") ;
    for( i = 0; i < K; i++ ) {//ввод массива
        for( j = 0; j < N; j++ ){
            scanf("%d", &x[i][j]); }}
    printf("введите sekond массив") ;
     for( i = 0; i < K; i++ ) {//ввод массива
        for( j = 0; j < N; j++ ){
            scanf("%d", &y[i][j]); }}
    printf("исходный массив 1 \n") ;
    for( i = 0; i < K; i++ ){ // ввывод массива
        for( j = 0; j < N; j++ )
            printf("%d ", x[i][j]); 
        printf("\n"); }
    printf("исходный массив 2 \n") ;
    for( i = 0; i < K; i++ ){ // ввывод массива
        for( j = 0; j < N; j++ )
            printf("%d ", y[i][j]);
        printf("\n"); }
    for( i = 0; i < K; i++ ){ 
        for( j = 0; j < N; j++ ) {
           z[i][j]=0 ;
            for (k = 0; k < N; k++) {
                c=0 ;
                c=(x[i][k] * y[k][j]);
                z[i][j] += c ;
    }   }   }
     printf("полученный массив \n") ;
    for( i = 0; i < K; i++ ){ // ввывод массива
        for( j = 0; j < N; j++ )
            printf("%d ", z[i][j]);
        printf("\n");
    }
        int qwertyuio;
    scanf("%d",&qwertyuio) ;
    return 0 ;

}
int lr7d(void){
    printf("see this programm in gethad") ;
    int qwertyuio;
    scanf("%d",&qwertyuio) ;
    getchar();
}